﻿namespace BulkyBook.Model
{
    public class Class1
    {

    }
}