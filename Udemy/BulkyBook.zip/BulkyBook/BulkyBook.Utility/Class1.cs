﻿namespace BulkyBook.Utility
{
    public class Class1
    {

    }
}