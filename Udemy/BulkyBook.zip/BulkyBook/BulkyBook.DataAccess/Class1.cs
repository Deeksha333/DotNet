﻿namespace BulkyBook.DataAccess
{
    public class Class1
    {

    }
}